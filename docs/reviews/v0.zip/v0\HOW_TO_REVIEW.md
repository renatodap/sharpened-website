# HOW_TO_REVIEW (30 min)

1) Read 00_overview.md (2m)
2) Read 01_positioning.md and 02_architecture.md (10m)
3) Skim 03–06 (8m)
4) Open _decisions.md and mark statuses (8m)
5) Check _open_questions.md and leave comments (2m)
